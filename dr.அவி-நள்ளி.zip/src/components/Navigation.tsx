import React from 'react';
import { motion } from 'motion/react';
import { Calendar, ClipboardList, BarChart3 } from 'lucide-react';
import { View } from '../types';

interface NavigationProps {
  currentView: View;
  onNavigate: (view: View) => void;
}

export default function Navigation({ currentView, onNavigate }: NavigationProps) {
  const items = [
    { id: 'tracker', icon: Calendar, label: 'பதிவு' },
    { id: 'trends', icon: BarChart3, label: 'பகுப்பாய்வு' },
    { id: 'history', icon: ClipboardList, label: 'வரலாறு' },
  ];

  return (
    <nav className="glass-nav rounded-[2.5rem] px-5 sm:px-8 py-5 flex justify-between items-center relative overflow-hidden">
      {items.map(({ id, icon: Icon, label }) => {
        const isActive = currentView === id;
        return (
          <button
            key={id}
            onClick={() => onNavigate(id as View)}
            aria-label={label}
            className={`relative flex flex-col items-center gap-1 transition-all duration-300 tap-highlight-none ${
              isActive ? 'text-[#14532d] scale-110' : 'text-[#c7c7cc] hover:text-[#1c1c1e]'
            }`}
          >
            <div className="relative z-10">
              <Icon size={24} strokeWidth={isActive ? 2.5 : 2} />
            </div>
            
            {isActive && (
              <motion.div 
                layoutId="navDot"
                className="absolute -bottom-2 w-1.5 h-1.5 bg-[#14532d] rounded-full shadow-sm"
                transition={{ type: "spring", stiffness: 400, damping: 28 }}
              />
            )}
          </button>
        );
      })}
    </nav>
  );
}
