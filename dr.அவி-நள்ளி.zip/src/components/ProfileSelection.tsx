import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Plus, Settings, User, Check, Trash2 } from 'lucide-react';
import { UserProfile } from '../types';

interface ProfileSelectionProps {
  profiles: UserProfile[];
  onSelect: (profile: UserProfile) => void;
  onAdd: (name: string, avatar: string, color: string) => void;
  onUpdate: (id: string, name: string, avatar: string, color: string) => void;
  onDelete: (id: string) => void;
}

const AVATARS = ['👩', '👧', '👵', '👱‍♀️', '👩‍🦰', '👩‍🦱', '👩‍🦳', '👩‍⚕️'];
const COLORS = ['#14532d', '#ef4444', '#3b82f6', '#f59e0b', '#8b5cf6', '#ec4899', '#06b6d4', '#10b981'];

export default function ProfileSelection({ profiles, onSelect, onAdd, onUpdate, onDelete }: ProfileSelectionProps) {
  const [showModal, setShowModal] = useState(false);
  const [editingProfile, setEditingProfile] = useState<UserProfile | null>(null);
  const [newName, setNewName] = useState('');
  const [selectedAvatar, setSelectedAvatar] = useState(AVATARS[0]);
  const [selectedColor, setSelectedColor] = useState(COLORS[0]);
  const [isEditing, setIsEditing] = useState(false);

  const handleOpenAdd = () => {
    setEditingProfile(null);
    setNewName('');
    setSelectedAvatar(AVATARS[0]);
    setSelectedColor(COLORS[0]);
    setShowModal(true);
  };

  const handleOpenEdit = (profile: UserProfile) => {
    setEditingProfile(profile);
    setNewName(profile.name);
    setSelectedAvatar(profile.avatar);
    setSelectedColor(profile.color);
    setShowModal(true);
  };

  const handleSubmit = () => {
    if (newName.trim()) {
      if (editingProfile) {
        onUpdate(editingProfile.id, newName, selectedAvatar, selectedColor);
      } else {
        onAdd(newName, selectedAvatar, selectedColor);
      }
      setShowModal(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-[#0a0a0a] z-[150] flex flex-col items-center justify-center p-6 overflow-y-auto">
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="max-w-4xl w-full text-center"
      >
        <h1 className="text-2xl sm:text-4xl font-bold text-white mb-12 tracking-tight px-4 leading-tight">
          யார் பயன்படுத்துகிறார்கள்?
          <span className="block text-xs font-medium text-white/40 mt-2 uppercase tracking-[0.2em]">Who's using Dr. Avi Nalli?</span>
        </h1>

        <div className="flex flex-wrap justify-center gap-8 sm:gap-12">
          {profiles.map((profile) => (
            <div key={profile.id} className="relative group">
              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                onClick={() => isEditing ? handleOpenEdit(profile) : onSelect(profile)}
                className="flex flex-col items-center gap-4 focus:outline-none"
              >
                <div 
                  className={`w-28 h-28 sm:w-36 sm:h-36 rounded-2xl flex items-center justify-center text-5xl sm:text-6xl shadow-2xl transition-all border-4 relative overflow-hidden ${
                    isEditing ? 'opacity-80' : 'group-hover:ring-4 ring-white/20'
                  }`}
                  style={{ backgroundColor: profile.color, borderColor: 'rgba(255,255,255,0.1)' }}
                >
                  {profile.avatar}
                  {isEditing && (
                    <div className="absolute inset-0 bg-black/40 flex items-center justify-center">
                      <Settings className="text-white animate-spin-slow" size={32} />
                    </div>
                  )}
                </div>
                <span className="text-white/80 font-bold text-lg group-hover:text-white transition-colors">
                  {profile.name}
                </span>
              </motion.button>

              {isEditing && (
                <motion.button
                  initial={{ scale: 0 }}
                  animate={{ scale: 1 }}
                  onClick={() => onDelete(profile.id)}
                  className="absolute -top-2 -right-2 w-10 h-10 bg-red-500 text-white rounded-full flex items-center justify-center shadow-xl border-4 border-[#0a0a0a] z-10"
                >
                  <Trash2 size={18} />
                </motion.button>
              )}
            </div>
          ))}

          {profiles.length < 5 && !isEditing && (
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              onClick={handleOpenAdd}
              className="flex flex-col items-center gap-4 focus:outline-none"
            >
              <div className="w-28 h-28 sm:w-36 sm:h-36 rounded-2xl bg-zinc-900 border-4 border-dashed border-zinc-800 flex items-center justify-center text-zinc-600 hover:text-zinc-400 hover:border-zinc-600 transition-all">
                <Plus size={48} strokeWidth={1.5} />
              </div>
              <span className="text-zinc-600 font-bold text-lg">சேர் (Add)</span>
            </motion.button>
          )}
        </div>

        <div className="mt-20">
          <button
            onClick={() => setIsEditing(!isEditing)}
            className="px-8 py-3 rounded-full border border-zinc-800 text-zinc-500 font-bold uppercase tracking-widest text-xs hover:text-white hover:border-white transition-all flex items-center gap-2 mx-auto"
          >
            {isEditing ? <Check size={16} /> : <Settings size={16} />}
            {isEditing ? 'சரி (Done)' : 'நிர்வகி (Manage Profiles)'}
          </button>
        </div>
      </motion.div>

      {/* Add/Edit Profile Modal */}
      <AnimatePresence>
        {showModal && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[200] bg-black/90 flex items-center justify-center p-6 backdrop-blur-xl"
          >
            <motion.div 
              initial={{ scale: 0.9, y: 20 }}
              animate={{ scale: 1, y: 0 }}
              className="bg-zinc-900 w-full max-w-sm rounded-[2rem] p-6 sm:p-8 border border-zinc-800"
            >
              <h2 className="text-xl font-bold text-white mb-6">
                {editingProfile ? 'விவரக்குறிப்பை மாற்று (Edit Profile)' : 'புதிய விவரக்குறிப்பு (Add Profile)'}
              </h2>
              
              <div className="space-y-6">
                <div className="flex justify-center mb-4">
                  <div 
                    className="w-20 h-20 rounded-2xl flex items-center justify-center text-4xl shadow-2xl border-4"
                    style={{ backgroundColor: selectedColor, borderColor: 'rgba(255,255,255,0.1)' }}
                  >
                    {selectedAvatar}
                  </div>
                </div>

                <div className="space-y-2">
                  <label className="text-[10px] uppercase font-black text-zinc-500 tracking-widest pl-1">பெயர் (Name)</label>
                  <input 
                    type="text" 
                    value={newName}
                    onChange={(e) => setNewName(e.target.value)}
                    placeholder="Enter name"
                    className="w-full bg-zinc-800 border-zinc-700 rounded-xl px-4 py-3 text-white focus:ring-2 ring-emerald-500 outline-none text-sm"
                    autoFocus
                  />
                </div>

                <div className="space-y-3">
                  <label className="text-[10px] uppercase font-black text-zinc-500 tracking-widest pl-1">Avatar</label>
                  <div className="flex flex-wrap gap-2 justify-center">
                    {AVATARS.map((a) => (
                      <button
                        key={a}
                        onClick={() => setSelectedAvatar(a)}
                        className={`w-9 h-9 rounded-lg text-lg flex items-center justify-center transition-all ${
                          selectedAvatar === a ? 'bg-emerald-500 scale-110 shadow-lg' : 'bg-zinc-800 hover:bg-zinc-700'
                        }`}
                      >
                        {a}
                      </button>
                    ))}
                  </div>
                </div>

                <div className="space-y-3">
                  <label className="text-[10px] uppercase font-black text-zinc-500 tracking-widest pl-1">Color</label>
                  <div className="flex flex-wrap gap-2 justify-center">
                    {COLORS.map((c) => (
                      <button
                        key={c}
                        onClick={() => setSelectedColor(c)}
                        className={`w-7 h-7 rounded-lg transition-all border-2 ${
                          selectedColor === c ? 'scale-110 border-white' : 'border-transparent'
                        }`}
                        style={{ backgroundColor: c }}
                      />
                    ))}
                  </div>
                </div>

                <div className="flex gap-3 pt-2">
                  <button 
                    onClick={handleSubmit}
                    className="flex-1 bg-emerald-500 text-white font-bold py-3 rounded-xl hover:bg-emerald-400 transition-all shadow-lg active:scale-95 flex flex-col items-center justify-center gap-0.5"
                  >
                    <span className="text-sm">சேமி</span>
                    <span className="text-[9px] opacity-70 uppercase tracking-tighter font-black">{editingProfile ? 'Save Changes' : 'Save & Create'}</span>
                  </button>
                  <button 
                    onClick={() => setShowModal(false)}
                    className="flex-1 bg-zinc-800 text-zinc-400 font-bold py-3 rounded-xl hover:bg-zinc-700 transition-all flex flex-col items-center justify-center"
                  >
                    <span className="text-sm">ரத்து (Cancel)</span>
                  </button>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
