import React, { useState, useMemo } from 'react';
import { motion } from 'motion/react';
import { Filter, Activity, TrendingUp } from 'lucide-react';
import { SymptomLog } from '../types';
import { format, parseISO, getYear, eachDayOfInterval, startOfYear, endOfYear, isSameDay } from 'date-fns';
import { 
  LineChart, 
  Line, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer, 
  AreaChart,
  Area,
  ReferenceArea
} from 'recharts';

interface TrendsProps {
  logs: SymptomLog[];
}

export default function Trends({ logs }: TrendsProps) {
  const currentYear = new Date().getFullYear();
  const [selectedYear, setSelectedYear] = useState(currentYear);

  const statusMap: Record<string, number> = {
    'stopped': 0,
    'regular': 1,
    'started': 2
  };

  const reverseStatusMap: Record<number, string> = {
    0: 'Stopped',
    1: 'Regular',
    2: 'Started'
  };

  const yearRange = useMemo(() => {
    const years = logs.map(log => getYear(parseISO(log.date)));
    if (years.length === 0) return [currentYear];
    const min = Math.min(...years);
    const max = Math.max(...years, currentYear);
    const range = [];
    for (let y = max; y >= min; y--) range.push(y);
    return range;
  }, [logs, currentYear]);

  // Chart data calculation for the entire year
  const chartData = useMemo(() => {
    const yearLogs = [...logs]
      .filter(log => getYear(parseISO(log.date)) === selectedYear)
      .sort((a, b) => a.date.localeCompare(b.date));

    if (yearLogs.length === 0) return [];

    return yearLogs.map(log => ({
      date: log.date,
      displayDate: format(parseISO(log.date), 'MMM dd'),
      status: statusMap[log.periodStatus || 'regular'] ?? 1,
      statusLabel: reverseStatusMap[statusMap[log.periodStatus || 'regular'] ?? 1],
      mood: log.mood.split(' ')[0]
    }));
  }, [logs, selectedYear]);

  const CustomTooltip = ({ active, payload }: any) => {
    if (active && payload && payload.length) {
      const data = payload[0].payload;
      return (
        <div className="bg-white p-4 shadow-xl border border-zinc-100 rounded-2xl">
          <p className="font-bold text-[#1c1c1e] mb-1">{format(parseISO(data.date), 'MMMM dd, yyyy')}</p>
          <div className="flex items-center gap-2">
            <span className={`w-2 h-2 rounded-full ${
              data.status === 2 ? 'bg-red-500' : data.status === 0 ? 'bg-zinc-400' : 'bg-emerald-400'
            }`} />
            <span className="text-sm font-semibold text-[#1c1c1e]">{data.statusLabel}</span>
            <span className="text-lg ml-1">{data.mood}</span>
          </div>
        </div>
      );
    }
    return null;
  };

  return (
    <div className="space-y-8 pb-10">
      <header className="flex justify-between items-end">
        <div>
          <h1 className="text-3xl font-bold text-[#1c1c1e] tracking-tight mb-1">பகுப்பாய்வு (Trends)</h1>
          <p className="text-[#c7c7cc] font-medium text-sm">Yearly Activity Progression</p>
        </div>

        <div className="relative group">
          <select 
            value={selectedYear}
            onChange={(e) => setSelectedYear(Number(e.target.value))}
            className="appearance-none bg-white border border-zinc-100 rounded-2xl px-6 py-2.5 pr-10 font-bold text-[#14532d] shadow-sm cursor-pointer outline-none transition-all hover:bg-zinc-50"
          >
            {yearRange.map(year => (
              <option key={year} value={year}>{year}</option>
            ))}
          </select>
          <div className="absolute right-4 top-1/2 -translate-y-1/2 pointer-events-none text-[#14532d] opacity-50">
            <Filter size={14} />
          </div>
        </div>
      </header>

      {/* Trend Chart Section */}
      <motion.div 
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        className="bg-white rounded-[2.5rem] p-6 shadow-sm border border-zinc-50 overflow-hidden"
      >
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-emerald-50 flex items-center justify-center text-[#14532d]">
              <TrendingUp size={20} />
            </div>
            <div>
              <h2 className="font-bold text-[#1c1c1e]">Yearly Trend</h2>
              <p className="text-[10px] text-[#c7c7cc] font-bold uppercase tracking-wider">Status Over Time</p>
            </div>
          </div>
          
          <div className="flex gap-4 items-center">
            <div className="flex items-center gap-1.5">
              <div className="w-2 h-2 rounded-full bg-red-500" />
              <span className="text-[9px] font-black text-zinc-400 uppercase">Start</span>
            </div>
            <div className="flex items-center gap-1.5">
              <div className="w-2 h-2 rounded-full bg-emerald-400" />
              <span className="text-[9px] font-black text-zinc-400 uppercase">Regular</span>
            </div>
            <div className="flex items-center gap-1.5">
              <div className="w-2 h-2 rounded-full bg-zinc-400" />
              <span className="text-[9px] font-black text-zinc-400 uppercase">Stop</span>
            </div>
          </div>
        </div>

        <div className="h-[350px] w-full -ml-4">
          {chartData.length > 0 ? (
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={chartData} margin={{ top: 10, right: 20, left: 0, bottom: 20 }}>
                <defs>
                  <linearGradient id="colorStatus" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#14532d" stopOpacity={0.1}/>
                    <stop offset="95%" stopColor="#14532d" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f8fafc" />
                <XAxis 
                  dataKey="displayDate" 
                  axisLine={false} 
                  tickLine={false} 
                  tick={{ fontSize: 9, fontWeight: 700, fill: '#c7c7cc' }}
                  minTickGap={30}
                />
                <YAxis 
                  domain={[0, 2]} 
                  ticks={[0, 1, 2]}
                  axisLine={false} 
                  tickLine={false} 
                  tickFormatter={(value) => reverseStatusMap[value]}
                  tick={{ fontSize: 9, fontWeight: 800, fill: '#c7c7cc', textTransform: 'uppercase' }} 
                />
                <Tooltip content={<CustomTooltip />} />
                <Area 
                  type="stepAfter" 
                  dataKey="status" 
                  stroke="#14532d" 
                  strokeWidth={3}
                  fillOpacity={1} 
                  fill="url(#colorStatus)" 
                  animationDuration={1500}
                />
              </AreaChart>
            </ResponsiveContainer>
          ) : (
            <div className="h-full w-full flex flex-col items-center justify-center text-[#c7c7cc] gap-3">
              <Activity size={48} className="opacity-20" />
              <p className="font-bold text-sm">No data for this year</p>
            </div>
          )}
        </div>
      </motion.div>

      <div className="bg-emerald-50/50 rounded-[2rem] p-6 border border-emerald-100/50">
        <h3 className="text-[#14532d] font-bold text-sm mb-2 uppercase tracking-wider">How to read this chart</h3>
        <p className="text-[#14532d]/70 text-xs leading-relaxed">
          The trend line connects your logs chronologically. 
          <strong className="mx-1 text-[#14532d]">Started</strong> is the highest point, 
          <strong className="mx-1 text-[#14532d]">Regular</strong> is the baseline, and 
          <strong className="mx-1 text-[#14532d]">Stopped</strong> is the lowest point. 
          Use this to visualize the duration and frequency of your cycles throughout the year.
        </p>
      </div>
    </div>
  );
}
