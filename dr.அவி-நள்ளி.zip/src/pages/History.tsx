import React from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Download, Calendar, Activity, Info, Trash2 } from 'lucide-react';
import { SymptomLog } from '../types';
import * as XLSX from 'xlsx';

interface HistoryProps {
  logs: SymptomLog[];
  profileName: string;
  onClear: () => void;
  onDelete: (id: string) => void;
}

export default function History({ logs, profileName, onClear, onDelete }: HistoryProps) {
  const [showConfirm, setShowConfirm] = React.useState(false);
  const [deletingId, setDeletingId] = React.useState<string | null>(null);

  const downloadExcel = () => {
    const data = logs.map(log => ({
      'Profile': profileName,
      'Date': log.date,
      'Period Status': log.periodStatus || 'Regular',
      'Symptoms': log.symptoms.join(', '),
      'Mood': log.mood.split(' ')[1] || log.mood,
      'Pain Level': log.painLevel,
      'Notes': log.notes
    }));

    const worksheet = XLSX.utils.json_to_sheet(data);
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, "Period History");
    XLSX.writeFile(workbook, `${profileName}_History_${new Date().toISOString().split('T')[0]}.xlsx`);
  };

  const handleClear = () => {
    onClear();
    setShowConfirm(false);
  };

  const handleDelete = (id: string) => {
    onDelete(id);
    setDeletingId(null);
  };

  const container = {
    hidden: { opacity: 0 },
    show: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1
      }
    }
  };

  const item = {
    hidden: { y: 20, opacity: 0 },
    show: { y: 0, opacity: 1 }
  };

  return (
    <div className="space-y-8 pb-10">
      <div className="flex justify-between items-start">
        <div>
          <h1 className="text-3xl font-bold text-[#1c1c1e] tracking-tight mb-1">
            வரலாறு
          </h1>
          <p className="text-[#c7c7cc] font-medium text-sm">
            Manage your past logs and records
          </p>
        </div>
        
        <div className="flex gap-2">
          {logs.length > 0 && (
            <div className="flex items-center gap-2">
              <AnimatePresence mode="wait">
                {showConfirm ? (
                  <motion.div
                    key="confirm"
                    initial={{ opacity: 0, scale: 0.9 }}
                    animate={{ opacity: 1, scale: 1 }}
                    exit={{ opacity: 0, scale: 0.9 }}
                    className="flex items-center gap-1 bg-red-50 p-1 rounded-2xl border border-red-100"
                  >
                    <button
                      onClick={handleClear}
                      className="px-3 py-1.5 bg-red-500 text-white text-[10px] font-bold rounded-xl"
                    >
                      Confirm Clear
                    </button>
                    <button
                      onClick={() => setShowConfirm(false)}
                      className="px-3 py-1.5 text-red-500 text-[10px] font-bold"
                    >
                      Cancel
                    </button>
                  </motion.div>
                ) : (
                  <motion.button
                    key="trash"
                    initial={{ opacity: 0, scale: 0.9 }}
                    animate={{ opacity: 1, scale: 1 }}
                    exit={{ opacity: 0, scale: 0.9 }}
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                    onClick={() => setShowConfirm(true)}
                    className="flex items-center justify-center p-2.5 bg-red-50 text-red-500 shadow-sm rounded-2xl border border-red-100"
                  >
                    <Trash2 size={18} />
                  </motion.button>
                )}
              </AnimatePresence>
              
              {!showConfirm && (
                <motion.button
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  onClick={downloadExcel}
                  className="flex items-center gap-2 px-5 py-2.5 bg-white text-[#14532d] shadow-sm rounded-2xl border border-zinc-100 font-bold text-xs uppercase tracking-wider"
                >
                  <Download size={16} />
                  Excel
                </motion.button>
              )}
            </div>
          )}
        </div>
      </div>

      <motion.div
        variants={container}
        initial="hidden"
        animate="show"
        className="space-y-4"
      >
        {logs.length > 0 ? (
          logs.map((log) => (
            <motion.div
              key={log.id}
              variants={item}
              className="bg-white rounded-[2rem] p-6 shadow-sm border border-zinc-50 flex flex-col gap-4"
            >
              <div className="flex justify-between items-start">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-2xl bg-emerald-50 flex items-center justify-center text-[#14532d]">
                    <Calendar size={20} />
                  </div>
                  <div>
                    <h3 className="font-bold text-[#1c1c1e] text-lg">
                      {new Date(log.date).toLocaleDateString('en-US', {
                        weekday: 'long',
                        year: 'numeric',
                        month: 'long',
                        day: 'numeric',
                      })}
                    </h3>
                    <p className="text-[10px] uppercase font-black tracking-widest text-[#c7c7cc]">
                      Pain Level: {log.painLevel}/5
                    </p>
                  </div>
                </div>
                <div className="flex flex-col items-end gap-2">
                  <div className="text-2xl" aria-label={log.mood}>
                    {log.mood.split(' ')[0]}
                  </div>
                  {log.periodStatus && log.periodStatus !== 'regular' && (
                    <span className={`text-[9px] font-black uppercase tracking-widest px-2 py-1 rounded-lg ${
                      log.periodStatus === 'started' 
                        ? 'bg-red-50 text-red-500 border border-red-100' 
                        : 'bg-zinc-100 text-zinc-500 border border-zinc-200'
                    }`}>
                      {log.periodStatus === 'started' ? 'Started' : 'Stopped'}
                    </span>
                  )}
                </div>
              </div>

              <div className="flex justify-between items-center mt-2">
                <div className="flex flex-wrap gap-2">
                  {log.symptoms.map(symptom => (
                    <span 
                      key={symptom}
                      className="px-4 py-1.5 bg-zinc-50 border border-zinc-100 rounded-full text-xs font-semibold text-[#3a3a3c]"
                    >
                      {symptom}
                    </span>
                  ))}
                </div>
                <AnimatePresence mode="wait">
                  {deletingId === log.id ? (
                    <motion.div
                      initial={{ opacity: 0, x: 20 }}
                      animate={{ opacity: 1, x: 0 }}
                      exit={{ opacity: 0, x: 20 }}
                      className="flex items-center gap-2 bg-red-50 p-1.5 rounded-2xl border border-red-100 shadow-sm"
                    >
                      <button
                        onClick={() => handleDelete(log.id)}
                        className="px-3 py-1.5 bg-red-500 text-white text-[10px] font-bold rounded-xl"
                      >
                        Delete?
                      </button>
                      <button
                        onClick={() => setDeletingId(null)}
                        className="px-2 py-1.5 text-zinc-400 text-[10px] font-bold hover:text-zinc-600 uppercase tracking-widest"
                      >
                        No
                      </button>
                    </motion.div>
                  ) : (
                    <motion.button
                      initial={{ opacity: 0.3 }}
                      whileHover={{ opacity: 1, scale: 1.1 }}
                      onClick={() => setDeletingId(log.id)}
                      className="p-2.5 text-red-500 hover:bg-red-50 transition-all rounded-2xl border border-transparent hover:border-red-100"
                      title="Delete Entry"
                    >
                      <Trash2 size={16} />
                    </motion.button>
                  )}
                </AnimatePresence>
              </div>

              {log.notes && (
                <div className="mt-2 p-4 bg-orange-50/30 rounded-2xl border border-orange-100/50 flex gap-3">
                  <Info size={16} className="text-orange-400 shrink-0 mt-0.5" />
                  <p className="text-xs text-zinc-600 leading-relaxed italic">
                    {log.notes}
                  </p>
                </div>
              )}
            </motion.div>
          ))
        ) : (
          <div className="bg-white rounded-[2.5rem] p-12 text-center shadow-sm border border-zinc-50 flex flex-col items-center gap-6">
            <div className="w-20 h-20 bg-zinc-50 rounded-full flex items-center justify-center">
              <Activity className="text-zinc-200" size={40} />
            </div>
            <div className="space-y-1">
              <h3 className="text-xl font-bold text-[#1c1c1e]">No Logs Found</h3>
              <p className="text-sm text-[#c7c7cc]">Start by adding your first entry</p>
            </div>
          </div>
        )}
      </motion.div>
    </div>
  );
}
