export interface SymptomLog {
  id: string;
  date: string;
  symptoms: string[];
  mood: string;
  painLevel: number; // 1-5
  notes: string;
  periodStatus?: 'started' | 'stopped' | 'regular';
}

export interface UserProfile {
  id: string;
  name: string;
  avatar: string; // Emoji
  color: string;
}

export type View = 'tracker' | 'history' | 'trends';

export interface PCOSInfo {
  nextPeriod?: string;
  cycleDay?: number;
}
