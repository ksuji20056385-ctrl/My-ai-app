import React, { useState, useEffect, useMemo } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { LogOut } from 'lucide-react';
import Navigation from './components/Navigation';
import Tracker from './pages/Tracker';
import History from './pages/History';
import Trends from './pages/Trends';
import Reminder from './pages/Reminder';
import ProfileSelection from './components/ProfileSelection';
import { View, SymptomLog, UserProfile } from './types';
import { format } from 'date-fns';

/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

const EMPTY_LOGS: SymptomLog[] = [];

export default function App() {
  const [loading, setLoading] = useState(true);
  const [showProfilePicker, setShowProfilePicker] = useState(false);
  const [currentView, setCurrentView] = useState<View>('tracker');
  
  // Profile State
  const [profiles, setProfiles] = useState<UserProfile[]>(() => {
    const saved = localStorage.getItem('dr_avi_profiles');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        return [];
      }
    }
    return [];
  });
  
  const [activeProfileId, setActiveProfileId] = useState<string | null>(() => {
    return localStorage.getItem('dr_avi_active_profile');
  });

  // Logs State - Stored by Profile ID
  const [allLogs, setAllLogs] = useState<Record<string, SymptomLog[]>>(() => {
    const saved = localStorage.getItem('dr_avi_all_logs');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        return {};
      }
    }
    return {};
  });

  const activeProfile = useMemo(() => profiles.find(p => p.id === activeProfileId), [profiles, activeProfileId]);
  const currentLogs = useMemo(() => {
    if (!activeProfileId) return EMPTY_LOGS;
    return allLogs[activeProfileId] || EMPTY_LOGS;
  }, [allLogs, activeProfileId]);

  // Sync state to localStorage
  useEffect(() => {
    localStorage.setItem('dr_avi_profiles', JSON.stringify(profiles));
  }, [profiles]);

  useEffect(() => {
    localStorage.setItem('dr_avi_all_logs', JSON.stringify(allLogs));
  }, [allLogs]);

  useEffect(() => {
    if (activeProfileId) {
      localStorage.setItem('dr_avi_active_profile', activeProfileId);
    } else {
      localStorage.removeItem('dr_avi_active_profile');
    }
  }, [activeProfileId]);

  // Handle Loading screen timer
  useEffect(() => {
    const timer = setTimeout(() => {
      setLoading(false);
      // If no profiles exist or none active, show picker
      if (profiles.length === 0 || !activeProfileId) {
        setShowProfilePicker(true);
      }
    }, 4500);
    return () => clearTimeout(timer);
  }, []);

  const handleUpdateProfile = (id: string, name: string, avatar: string, color: string) => {
    setProfiles(prev => prev.map(p => p.id === id ? { ...p, name, avatar, color } : p));
  };

  const handleSaveLog = (newLog: SymptomLog) => {
    if (!activeProfileId) return;
    setAllLogs(prev => ({
      ...prev,
      [activeProfileId]: [newLog, ...(prev[activeProfileId] || EMPTY_LOGS)]
    }));
  };

  const handleDeleteLog = (id: string) => {
    if (!activeProfileId) return;
    setAllLogs(prev => ({
      ...prev,
      [activeProfileId]: (prev[activeProfileId] || EMPTY_LOGS).filter(log => log.id !== id)
    }));
  };

  const handleClearLogs = () => {
    if (!activeProfileId) return;
    setAllLogs(prev => ({
      ...prev,
      [activeProfileId]: []
    }));
  };

  const handleAddProfile = (name: string, avatar: string, color: string) => {
    const newId = Date.now().toString();
    const newProfile: UserProfile = {
      id: newId,
      name,
      avatar,
      color
    };
    setProfiles(prev => [...prev, newProfile]);
    
    const today = format(new Date(), 'yyyy-MM-dd');
    setAllLogs(prev => ({
      ...prev,
      [newId]: [{
        id: 'welcome-' + newId,
        date: today,
        symptoms: ['மிதமான ஓட்டம்'],
        mood: '😌 அமைதி',
        painLevel: 2,
        notes: `Welcome to Dr.அவி நள்ளி, ${name}!`
      }]
    }));

    // Auto-select if it's the first profile
    if (profiles.length === 0) {
      setActiveProfileId(newId);
      setShowProfilePicker(false);
    }
  };

  const handleDeleteProfile = (id: string) => {
    setProfiles(prev => prev.filter(p => p.id !== id));
    setAllLogs(prev => {
      const next = { ...prev };
      delete next[id];
      return next;
    });
    if (activeProfileId === id) {
      setActiveProfileId(null);
      setShowProfilePicker(true);
    }
  };

  const selectProfile = (profile: UserProfile) => {
    setActiveProfileId(profile.id);
    setShowProfilePicker(false);
  };

  if (loading) {
    return (
      <div className="fixed inset-0 fantasy-bg flex flex-col items-center justify-center z-[250] overflow-hidden">
        {/* Particle System */}
        <div className="absolute inset-0 pointer-events-none">
          {[...Array(15)].map((_, i) => (
            <motion.div
              key={i}
              initial={{ 
                x: Math.random() * 100 + 'vw', 
                y: Math.random() * 100 + 'vh',
                scale: 0,
                opacity: 0 
              }}
              animate={{ 
                scale: [0, 1, 0],
                opacity: [0, 0.4, 0],
                y: [null, '-20px', null]
              }}
              transition={{ 
                duration: 4 + Math.random() * 4, 
                repeat: Infinity,
                delay: Math.random() * 5
              }}
              className="absolute w-1.5 h-1.5 bg-rose-300 rounded-full blur-[1px]"
            />
          ))}
        </div>

        <motion.div 
          className="relative z-10 flex flex-col items-center"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
        >
          {/* Main Magical Charm */}
          <motion.div
            initial={{ scale: 0.8, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            transition={{ duration: 1.5, ease: "easeOut" }}
            className="relative mb-16"
          >
            {/* Glowing Aura */}
            <div className="absolute inset-[-40px] bg-rose-500/10 blur-[60px] rounded-full animate-pulse-soft" />
            <div className="absolute inset-[-20px] bg-rose-400/5 blur-[30px] rounded-full animate-pulse-soft" style={{ animationDelay: '-2s' }} />

            <div className="w-32 h-32 sm:w-40 sm:h-40 rounded-full glass-morphism flex items-center justify-center border border-white/10 shadow-[0_0_100px_rgba(244,63,94,0.15)] relative overflow-hidden group">
              {/* Spinning Sacred Geometry (Subtle) */}
              <motion.div 
                animate={{ rotate: 360 }}
                transition={{ duration: 20, repeat: Infinity, ease: "linear" }}
                className="absolute inset-2 border border-emerald-500/10 rounded-full"
              />
              <motion.div 
                animate={{ rotate: -360 }}
                transition={{ duration: 15, repeat: Infinity, ease: "linear" }}
                className="absolute inset-6 border border-emerald-400/5 rounded-full border-dashed"
              />

              {/* Central Soul/Doctor Icon */}
              <div className="relative">
                <motion.span 
                  className="text-7xl sm:text-8xl drop-shadow-[0_0_30px_rgba(255,255,255,0.3)] block"
                  animate={{ 
                    y: [0, -10, 0],
                    scale: [1, 1.05, 1]
                  }}
                  transition={{ duration: 6, repeat: Infinity, ease: "easeInOut" }}
                >
                  👩‍⚕️
                </motion.span>
                <motion.div 
                  className="absolute -bottom-2 -right-2 text-3xl"
                  animate={{ 
                    rotate: [0, 10, -10, 0],
                    scale: [1, 1.1, 1]
                  }}
                  transition={{ duration: 3, repeat: Infinity, ease: "easeInOut" }}
                >
                  ✨
                </motion.div>
              </div>
            </div>
          </motion.div>

          {/* Elegant Text */}
          <div className="text-center space-y-6">
            <motion.div
              initial={{ y: 20, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              transition={{ delay: 0.8, duration: 1 }}
            >
              <h1 className="font-girly text-5xl sm:text-7xl text-white tracking-wide leading-none mb-4">
                Dr. <span className="text-rose-300 drop-shadow-[0_0_15px_rgba(253,164,175,0.5)]">அவி நள்ளி</span>
              </h1>
              <div className="flex items-center justify-center gap-3">
                <div className="h-[1px] w-8 bg-gradient-to-r from-transparent to-rose-400/50" />
                <span className="text-rose-300/80 uppercase tracking-[0.4em] text-[9px] font-black">Period Health Sanctuary</span>
                <div className="h-[1px] w-8 bg-gradient-to-l from-transparent to-rose-400/50" />
              </div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 1.8, duration: 1.2 }}
              className="space-y-1"
            >
              <p className="text-emerald-50/60 font-serif italic text-lg sm:text-xl">
                உங்களுக்கான பிரத்யேக பீரியட் கண்காணிப்பான்
              </p>
              <p className="text-white/20 text-[9px] uppercase tracking-[0.2em] font-medium">
                Your Personal Period Health Sanctuary
              </p>
            </motion.div>
          </div>
        </motion.div>

        {/* Bottom Detail */}
        <motion.div 
          initial={{ opacity: 0 }}
          animate={{ opacity: 0.4 }}
          transition={{ delay: 3, duration: 1 }}
          className="absolute bottom-12 text-white/10 text-[10px] uppercase tracking-[0.5em] font-black"
        >
          Magical Health Monitoring
        </motion.div>
      </div>
    );
  }

  if (showProfilePicker || !activeProfileId) {
    return (
      <ProfileSelection 
        profiles={profiles} 
        onSelect={selectProfile} 
        onAdd={handleAddProfile}
        onUpdate={handleUpdateProfile}
        onDelete={handleDeleteProfile}
      />
    );
  }

  const renderView = () => {
    switch (currentView) {
      case 'tracker':
        return <Tracker onSave={handleSaveLog} onNavigate={setCurrentView} />;
      case 'history':
        return <History logs={currentLogs} profileName={activeProfile?.name || 'User'} onClear={handleClearLogs} onDelete={handleDeleteLog} />;
      case 'trends':
        return <Trends logs={currentLogs} />;
      case 'reminder':
        return <Reminder logs={currentLogs} />;
      default:
        return <Tracker onSave={handleSaveLog} onNavigate={setCurrentView} />;
    }
  };

  return (
    <div className="min-h-screen max-w-lg mx-auto bg-[#f1f4f0] relative overflow-x-hidden">
      {/* Mini Profile Header */}
      <header className="fixed top-0 left-0 right-0 max-w-lg mx-auto px-6 py-4 flex justify-between items-center z-40">
        <button 
          onClick={() => setShowProfilePicker(true)}
          className="flex items-center gap-2 bg-white px-3 py-2 rounded-2xl shadow-sm border border-zinc-100 transition-all hover:shadow-md active:scale-95"
        >
          <div 
            className="w-8 h-8 rounded-lg flex items-center justify-center text-lg"
            style={{ backgroundColor: activeProfile?.color }}
          >
            {activeProfile?.avatar}
          </div>
          <span className="font-bold text-xs text-[#1c1c1e]">{activeProfile?.name}</span>
        </button>

        <div className="flex items-center gap-2">
           <button 
            onClick={() => setActiveProfileId(null)}
            className="p-3 bg-white text-zinc-400 rounded-2xl shadow-sm border border-zinc-100 hover:text-red-500 transition-all"
            title="Switch User"
           >
            <LogOut size={18} />
          </button>
        </div>
      </header>

      <main className="px-4 sm:px-6 pt-24 pb-32">
        <AnimatePresence mode="wait">
          <motion.div
            key={`${activeProfileId}-${currentView}`}
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -20 }}
            transition={{ type: "spring", stiffness: 300, damping: 28 }}
          >
            {renderView()}
          </motion.div>
        </AnimatePresence>
      </main>
      
      <div className="fixed bottom-6 sm:bottom-8 left-0 right-0 px-4 sm:px-6 z-50">
        <div className="max-w-lg mx-auto">
          <Navigation 
            currentView={currentView} 
            onNavigate={setCurrentView} 
          />
        </div>
      </div>
    </div>
  );
}
