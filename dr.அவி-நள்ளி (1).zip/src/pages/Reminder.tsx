import React from 'react';
import { motion } from 'motion/react';
import { ShieldAlert, Calendar, CheckCircle2, AlertCircle, Info, Stethoscope, Activity } from 'lucide-react';
import { SymptomLog } from '../types';
import { differenceInDays, parseISO, format, addDays } from 'date-fns';

interface ReminderProps {
  logs: SymptomLog[];
}

export default function Reminder({ logs }: ReminderProps) {
  // Sort logs by date descending to get most recent first
  const sortedLogs = [...logs].sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
  
  // Find events
  const lastStopEntry = sortedLogs.find(log => log.periodStatus === 'stopped');
  const lastStartEntry = sortedLogs.find(log => log.periodStatus === 'started');
  
  // Find the previous cycle's end (the stop before the current start)
  const prevStopEntry = lastStartEntry 
    ? sortedLogs.find(log => log.periodStatus === 'stopped' && new Date(log.date) < new Date(lastStartEntry.date))
    : null;

  const today = new Date();
  
  const daysSinceLastStop = lastStopEntry ? differenceInDays(today, parseISO(lastStopEntry.date)) : 0;
  
  // Period Duration: Last Start to Last Stop (if stop happened after start)
  const periodDuration = (lastStartEntry && lastStopEntry && new Date(lastStopEntry.date) >= new Date(lastStartEntry.date))
    ? differenceInDays(parseISO(lastStopEntry.date), parseISO(lastStartEntry.date)) + 1
    : 0;

  // Dry Gap: Previous Stop to Current Start
  const dryGap = (prevStopEntry && lastStartEntry)
    ? differenceInDays(parseISO(lastStartEntry.date), parseISO(prevStopEntry.date))
    : 0;

  const getStatus = () => {
    if (!lastStopEntry) {
      return {
        type: 'info',
        message: 'தகவல்கள் தேவை',
        sub: 'பீரியட் முடிந்த தேதியை பதிவு செய்யவும்.',
        advice: 'குறைந்தது ஒரு முழு சுழற்சியைப் பதிவு செய்தால் துல்லியமான கணக்கீடு கிடைக்கும்.',
        icon: <Info className="text-blue-500" size={32} />
      };
    }

    // Logic for checkup remains similar but more informed
    if (daysSinceLastStop > 40 && (!lastStartEntry || parseISO(lastStartEntry.date) <= parseISO(lastStopEntry.date))) {
      return {
        type: 'danger',
        message: 'பரிசோதனை தேவை',
        sub: `கடைசி பீரியட் முடிந்து ${daysSinceLastStop} நாட்கள் ஆகிறது.`,
        advice: 'இயல்பான சுழற்சி காலம் தாண்டிவிட்டது. மருத்துவரை அணுகவும்.',
        icon: <ShieldAlert className="text-red-500" size={32} />
      };
    }

    return {
      type: 'normal',
      message: 'கண்காணிப்பு தொடர்கிறது',
      sub: 'உங்கள் சுழற்சி ஆரோக்கியமாகக் கணக்கிடப்படுகிறது.',
      advice: 'பீரியட் தொடங்கிய மற்றும் முடிந்த தேதிகளைத் தவறாமல் பதிவு செய்யவும்.',
      icon: <CheckCircle2 className="text-emerald-400" size={32} />
    };
  };

  const status = getStatus();

  // PCOS Engine - Smart Comment Logic
  const getEngineComment = () => {
    if (!lastStopEntry) return "போதிய தரவுகள் இல்லை. உங்கள் பீரியட் முடிந்ததும் 'Stopped' என்று பதிவு செய்யவும்.";
    
    let comments = [];

    // 1. Check current delay
    if (daysSinceLastStop > 40) {
      comments.push("கடைசி பீரியட் முடிந்து 40 நாட்களுக்கு மேல் ஆகிவிட்டதால், இது தாமதமான சுழற்சியாகக் கருதப்படுகிறது. ஹார்மோன் சமநிலையின்மை அல்லது PCOS காரணமாக இருக்கலாம்.");
    } else if (daysSinceLastStop > 32) {
      comments.push("உங்கள் அடுத்த சுழற்சி தொடங்குவதற்கான நேரம் நெருங்கிவிட்டது. அறிகுறிகளைக் கவனிக்கவும்.");
    }

    // 2. Check Period Duration
    if (periodDuration > 8) {
      comments.push(`உங்களுக்கு ${periodDuration} நாட்கள் நீடித்த பீரியட் இருந்தது. இது வழக்கத்தை விட அதிகம். அதிக இரத்தப்போக்கு இருந்தால் மருத்துவரை அணுகவும்.`);
    } else if (periodDuration > 0 && periodDuration < 3) {
      comments.push(`இந்த முறை பீரியட் ${periodDuration} நாட்களே நீடித்தது. இது மிகக் குறைவான ஓட்டத்தைக் குறிக்கலாம்.`);
    }

    // 3. Check Cycle Gap (Dry Gap)
    if (dryGap > 0) {
      if (dryGap < 14) {
        comments.push("சுழற்சிகளுக்கு இடையிலான இடைவெளி மிகக் குறைவாக உள்ளது. இது கருப்பை ஆரோக்கியம் சார்ந்த ஒரு அறிகுறியாக இருக்கலாம்.");
      } else if (dryGap > 35) {
        comments.push("இரண்டு சுழற்சிகளுக்கு இடையே அதிக இடைவெளி இருப்பது PCOS உள்ளவர்களுக்குப் பொதுவானது.");
      }
    }

    if (comments.length === 0) {
      return "உங்கள் தற்போதைய தகவல்களின்படி சுழற்சி சீராக உள்ளது. ஆரோக்கியமான உணவும், உடற்பயிற்சியும் தொடரவும்.";
    }

    return comments.join(' ');
  };

  const engineComment = getEngineComment();

  return (
    <div className="space-y-6 pb-10 font-inter">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-[#1c1c1e] tracking-tight mb-1">
          சுழற்சி ஆய்வறிக்கை
        </h1>
        <p className="text-[#c7c7cc] font-medium text-sm">
          PCOS Engine & Smart Insights
        </p>
      </div>

      {/* Engine Insight Box */}
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        className="bg-zinc-900 rounded-[2.5rem] p-8 relative overflow-hidden"
      >
        <div className="relative z-10">
          <div className="flex items-center gap-3 mb-6">
            <div className="w-10 h-10 rounded-2xl bg-emerald-500/20 flex items-center justify-center text-emerald-400">
              <Stethoscope size={24} />
            </div>
            <div>
              <h3 className="text-white font-bold text-lg leading-tight">PCOS கணினி மதிப்பீடு</h3>
              <p className="text-emerald-400/60 text-[10px] font-black uppercase tracking-widest">Smart Engine Insight</p>
            </div>
          </div>
          
          <p className="text-emerald-50 text-sm leading-relaxed font-medium italic mb-2">
            " {engineComment} "
          </p>
        </div>
        
        {/* Decorative Grid Background */}
        <div className="absolute inset-0 opacity-10 pointer-events-none" 
             style={{ backgroundImage: 'radial-gradient(circle, #10b981 1px, transparent 1px)', backgroundSize: '24px 24px' }} />
      </motion.div>

      {/* Main Status Cards */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="bg-white rounded-[2.5rem] p-7 shadow-sm border border-zinc-100"
      >
        <div className="flex items-center gap-4 mb-6">
          <div className="p-4 rounded-2xl bg-zinc-50">
            {status.icon}
          </div>
          <div>
            <h2 className="text-xl font-bold text-zinc-800">{status.message}</h2>
            <p className="text-zinc-500 text-xs font-medium">{status.sub}</p>
          </div>
        </div>

        {/* Gap Dashboard */}
        <div className="grid grid-cols-1 gap-3">
          <div className="flex justify-between items-center bg-zinc-50/50 p-4 rounded-2xl border border-zinc-100">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-full bg-rose-50 flex items-center justify-center text-rose-500">
                <Activity size={16} />
              </div>
              <span className="text-sm font-semibold text-zinc-600">பீரியட் நாட்கள் (Start to End)</span>
            </div>
            <span className="font-bold text-rose-600">{periodDuration || '--'} நாட்கள்</span>
          </div>

          <div className="flex justify-between items-center bg-zinc-50/50 p-4 rounded-2xl border border-zinc-100">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-full bg-emerald-50 flex items-center justify-center text-emerald-500">
                <Calendar size={16} />
              </div>
              <span className="text-sm font-semibold text-zinc-600">இடைவெளி (End to New Start)</span>
            </div>
            <span className="font-bold text-emerald-600">{dryGap || '--'} நாட்கள்</span>
          </div>

          <div className="flex justify-between items-center bg-zinc-900 p-4 rounded-2xl text-white">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-full bg-white/10 flex items-center justify-center">
                <Info size={16} />
              </div>
              <span className="text-sm font-semibold">இன்றைய நிலை (End to Today)</span>
            </div>
            <span className="font-bold">{daysSinceLastStop} நாட்கள்</span>
          </div>
        </div>

        <div className="mt-6 p-5 rounded-2xl bg-[#14532d] text-white flex gap-4">
          <Stethoscope className="shrink-0" size={20} />
          <p className="text-xs leading-relaxed font-medium opacity-90">
            {status.advice}
          </p>
        </div>
      </motion.div>

      {/* Logic Explanation */}
      <div className="bg-rose-50 border border-rose-100 rounded-[2rem] p-6">
        <h4 className="font-bold text-rose-800 text-sm mb-3">கணக்கீடு விளக்கம்:</h4>
        <ul className="space-y-3">
          <li className="flex gap-3 text-xs text-rose-700">
            <div className="w-5 h-5 rounded-full bg-rose-200 flex items-center justify-center shrink-0 font-bold">1</div>
            <p><b>Start to End:</b> உங்கள் பீரியட் எத்தனை நாட்கள் நீடித்தது என்பதைக் குறிக்கும்.</p>
          </li>
          <li className="flex gap-3 text-xs text-rose-700">
            <div className="w-5 h-5 rounded-full bg-rose-200 flex items-center justify-center shrink-0 font-bold">2</div>
            <p><b>End to New Start:</b> சென்ற பீரியட் முடிந்ததிலிருந்து புதியது தொடங்கும் வரை இருந்த தெளிவான நாட்கள்.</p>
          </li>
        </ul>
      </div>
    </div>
  );
}
