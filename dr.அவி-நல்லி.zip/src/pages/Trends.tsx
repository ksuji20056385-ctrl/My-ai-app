import React from 'react';
import { motion } from 'motion/react';
import { Activity, Sparkles } from 'lucide-react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, AreaChart, Area } from 'recharts';

const mockData = [
  { date: 'ஏப் 01', pain: 2, mood: 3 },
  { date: 'ஏப் 05', pain: 4, mood: 2 },
  { date: 'ஏப் 10', pain: 1, mood: 4 },
  { date: 'ஏப் 15', pain: 2, mood: 5 },
  { date: 'ஏப் 17', pain: 1, mood: 4 },
  { date: 'ஏப் 20', pain: 3, mood: 3 },
  { date: 'ஏப் 25', pain: 5, mood: 2 },
];

export default function Trends() {
  const container = {
    hidden: { opacity: 0 },
    show: {
      opacity: 1,
      transition: { staggerChildren: 0.1 }
    }
  };

  const item = {
    hidden: { opacity: 0, y: 20 },
    show: { opacity: 1, y: 0, transition: { type: "spring", stiffness: 300, damping: 25 } }
  };

  return (
    <motion.div 
      variants={container}
      initial="hidden"
      animate="show"
      className="space-y-10 pb-16"
    >
      <header className="text-center pt-4">
        <motion.h1 variants={item} className="text-4xl font-bold tracking-tight text-[#1c1c1e]">Trends</motion.h1>
        <motion.p variants={item} className="text-[#c7c7cc] font-black text-[10px] uppercase tracking-[0.25em] mt-3">Daily Analysis</motion.p>
      </header>

      <motion.section variants={item} className="space-y-6">
        <div className="apple-card">
          <div className="mb-8 flex justify-between items-start">
            <div>
              <h2 className="text-[10px] font-black uppercase tracking-[0.2em] text-[#c7c7cc]">Symptom Intensity</h2>
              <p className="text-3xl font-bold text-[#1c1c1e] mt-1 tabular-nums">மிதமானது</p>
            </div>
            <div className="w-10 h-10 rounded-xl bg-orange-50 flex items-center justify-center">
              <Activity className="text-orange-500" size={20} />
            </div>
          </div>
          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={mockData}>
                <defs>
                  <linearGradient id="colorPain" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#14532d" stopOpacity={0.2}/>
                    <stop offset="95%" stopColor="#14532d" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f0f0f0" />
                <XAxis 
                  dataKey="date" 
                  axisLine={false} 
                  tickLine={false} 
                  tick={{fontSize: 9, fill: '#c7c7cc', fontWeight: 900}} 
                  dy={10}
                />
                <YAxis hide />
                <Tooltip 
                  cursor={{ stroke: '#14532d', strokeWidth: 1 }}
                  contentStyle={{ borderRadius: '16px', border: 'none', boxShadow: '0 8px 32px rgba(0,0,0,0.1)', background: 'rgba(255,255,255,0.9)', backdropFilter: 'blur(4px)' }}
                />
                <Area 
                  type="monotone" 
                  dataKey="pain" 
                  stroke="#14532d" 
                  fillOpacity={1} 
                  fill="url(#colorPain)" 
                  strokeWidth={3} 
                  animationDuration={1500}
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>
      </motion.section>

      <motion.section variants={item} className="space-y-6">
        <div className="apple-card">
          <div className="mb-8 flex justify-between items-start">
            <div>
              <h2 className="text-[10px] font-black uppercase tracking-[0.2em] text-[#c7c7cc]">Mood Stability</h2>
              <p className="text-3xl font-bold text-[#1c1c1e] mt-1">அமைதி</p>
            </div>
            <div className="w-10 h-10 rounded-xl bg-blue-50 flex items-center justify-center">
              <Sparkles className="text-blue-500" size={20} />
            </div>
          </div>
          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={mockData}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f0f0f0" />
                <XAxis 
                  dataKey="date" 
                  axisLine={false} 
                  tickLine={false} 
                  tick={{fontSize: 9, fill: '#c7c7cc', fontWeight: 900}} 
                  dy={10}
                />
                <YAxis hide />
                <Tooltip 
                  cursor={{ stroke: '#065f46', strokeWidth: 1 }}
                  contentStyle={{ borderRadius: '16px', border: 'none', boxShadow: '0 8px 32px rgba(0,0,0,0.1)', background: 'rgba(255,255,255,0.9)', backdropFilter: 'blur(4px)' }}
                />
                <Line 
                  type="monotone" 
                  dataKey="mood" 
                  stroke="#14532d" 
                  strokeWidth={3} 
                  dot={{ r: 5, fill: '#14532d', strokeWidth: 3, stroke: '#fff' }} 
                  activeDot={{ r: 8, strokeWidth: 0 }} 
                  animationDuration={1500}
                />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>
      </motion.section>

      <motion.div 
        variants={item}
        className="bg-[#14532d] p-8 rounded-[2.5rem] relative overflow-hidden group shadow-2xl shadow-green-900/20"
      >
        <motion.div 
          animate={{ scale: [1, 1.2, 1] }}
          transition={{ repeat: Infinity, duration: 8 }}
          className="absolute -top-10 -right-10 w-40 h-40 bg-white/10 rounded-full blur-3xl"
        />
        <p className="text-lg text-white font-medium leading-relaxed italic opacity-95 relative z-10">
          "Based on your data, your mood is most stable during the Follicular Phase, while energy levels peak around day 14."
        </p>
      </motion.div>
    </motion.div>
  );
}

