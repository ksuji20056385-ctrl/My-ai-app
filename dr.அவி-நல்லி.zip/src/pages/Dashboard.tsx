import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Activity, Droplets, Sparkles, ChevronRight, X, Calendar } from 'lucide-react';
import { View, PCOSInfo, SymptomLog } from '../types';

interface DashboardProps {
  info: PCOSInfo;
  onNavigate: (view: View) => void;
  logs: SymptomLog[];
}

export default function Dashboard({ info, onNavigate, logs }: DashboardProps) {
  const [showLogs, setShowLogs] = useState(false);
  const container = {
    hidden: { opacity: 0 },
    show: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1,
        delayChildren: 0.2
      }
    }
  };

  const item = {
    hidden: { opacity: 0, y: 20 },
    show: { 
      opacity: 1, 
      y: 0,
      transition: { type: "spring", stiffness: 300, damping: 24 }
    }
  };

  const today = new Intl.DateTimeFormat('ta-IN', { 
    weekday: 'long', 
    month: 'long', 
    day: 'numeric' 
  }).format(new Date());

  return (
    <motion.div 
      variants={container}
      initial="hidden"
      animate="show"
      className="space-y-10 pb-8 transform-gpu"
    >
      <header className="flex flex-col items-center text-center py-4 transform-gpu">
        <motion.span 
          variants={item}
          className="text-[10px] font-black uppercase tracking-[0.25em] text-[#c7c7cc] mb-3"
        >
          Cycle Dashboard
        </motion.span>
        <motion.h1 
          variants={item}
          className="text-3xl font-bold tracking-tight text-[#1c1c1e] px-4 capitalize"
        >
          {today}
        </motion.h1>
      </header>

      {/* Primary Cycle - Large Interactive Circle */}
      <motion.div 
        variants={item}
        className="flex justify-center transform-gpu"
      >
        <div className="relative group cursor-default">
          <motion.div 
            animate={{ rotate: 360 }}
            transition={{ duration: 60, repeat: Infinity, ease: "linear" }}
            className="absolute inset-0 rounded-full border-[2px] border-dashed border-[#14532d]/20 scale-125 pointer-events-none"
          />
          <div className="relative w-64 h-64 sm:w-72 sm:h-72 flex items-center justify-center bg-white rounded-full shadow-[0_20px_50px_rgba(0,0,0,0.04)] border border-white">
            {/* Background circle */}
            <div className="absolute inset-3 sm:inset-4 rounded-full border-[8px] sm:border-[10px] border-zinc-50" />
            
            {/* Dynamic progress arc */}
            <motion.div 
              initial={{ rotate: -90, opacity: 0 }}
              animate={{ rotate: 45, opacity: 1 }}
              transition={{ delay: 0.3, duration: 1.2, ease: "circOut" }}
              className="absolute inset-3 sm:inset-4 rounded-full border-[8px] sm:border-[10px] border-transparent border-t-[#14532d] border-r-[#14532d] transform-gpu" 
            />
            
            <div className="text-center z-10 px-4">
              <p className="text-[#c7c7cc] font-black text-[9px] sm:text-[10px] uppercase tracking-widest mb-1">நாள்</p>
              <div className="text-6xl sm:text-8xl font-bold text-[#1c1c1e] tabular-nums tracking-tighter leading-none">14</div>
              <p className="text-[#14532d] font-bold text-[12px] sm:text-sm mt-2 sm:mt-3 bg-green-50 px-3 sm:px-4 py-1 sm:py-1.5 rounded-full inline-block">Follicular Phase</p>
            </div>

            {/* Floating indicator */}
            <motion.div 
              animate={{ y: [0, -4, 0] }}
              transition={{ repeat: Infinity, duration: 4, ease: "easeInOut" }}
              className="absolute top-8 right-8 text-yellow-500 pointer-events-none"
            >
              <Sparkles size={20} fill="currentColor" />
            </motion.div>
          </div>
        </div>
      </motion.div>

      {/* Bento Grid Metrics */}
      <div className="grid grid-cols-2 gap-3 sm:gap-4 px-1">
        <motion.div 
          variants={item}
          className="apple-card card-interactive min-h-[9rem] sm:min-h-[10rem] flex flex-col justify-between"
        >
          <div className="w-8 h-8 sm:w-10 sm:h-10 rounded-xl sm:rounded-2xl bg-teal-50 flex items-center justify-center">
            <Droplets className="text-[#14532d]" size={18} />
          </div>
          <div>
            <p className="text-[9px] sm:text-[10px] font-black uppercase tracking-wider text-[#c7c7cc] mb-1">Period இன்னும்</p>
            <p className="text-xl sm:text-2xl font-bold text-[#1c1c1e]">14 நாட்கள்</p>
          </div>
        </motion.div>
        
        <motion.div 
          variants={item}
          className="apple-card card-interactive min-h-[9rem] sm:min-h-[10rem] flex flex-col justify-between"
        >
          <div className="w-8 h-8 sm:w-10 sm:h-10 rounded-xl sm:rounded-2xl bg-emerald-50 flex items-center justify-center">
            <Activity className="text-[#14532d]" size={18} />
          </div>
          <div>
            <p className="text-[9px] sm:text-[10px] font-black uppercase tracking-wider text-[#c7c7cc] mb-1">Symptoms</p>
            <p className="text-xl sm:text-2xl font-bold text-[#1c1c1e]">ஏதுமில்லை</p>
          </div>
        </motion.div>

        <motion.div 
          variants={item}
          onClick={() => setShowLogs(true)}
          className="bento-full apple-card card-interactive p-5 flex items-center justify-between group"
        >
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 rounded-2xl bg-[#14532d] flex items-center justify-center shadow-lg shadow-green-900/20 group-active:scale-90 transition-transform">
              <Sparkles className="text-white" size={24} />
            </div>
            <div>
              <p className="font-bold text-[#1c1c1e]">சமீபத்திய Logs</p>
              <p className="text-xs text-[#c7c7cc] font-medium tracking-wide">உங்கள் ஆரோக்கியத்தைக் கண்காணிக்கவும்</p>
            </div>
          </div>
          <ChevronRight size={20} className="text-[#c7c7cc]" />
        </motion.div>
      </div>

      {/* Recent Logs Modal */}
      <AnimatePresence>
        {showLogs && (
          <>
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setShowLogs(false)}
              className="fixed inset-0 bg-black/20 backdrop-blur-sm z-[100]"
            />
            <motion.div 
              initial={{ y: "100%" }}
              animate={{ y: 0 }}
              exit={{ y: "100%" }}
              transition={{ type: "spring", stiffness: 300, damping: 30 }}
              className="fixed bottom-0 left-0 right-0 bg-white rounded-t-[2.5rem] z-[101] max-h-[85vh] overflow-hidden flex flex-col shadow-2xl"
            >
              {/* Handle */}
              <div className="w-12 h-1.5 bg-zinc-200 rounded-full mx-auto mt-4 mb-2" />
              
              <div className="px-6 py-4 flex justify-between items-center border-b border-zinc-50">
                <h2 className="text-2xl font-bold text-[#1c1c1e]">சமீபத்திய வரவுகள்</h2>
                <button 
                  onClick={() => setShowLogs(false)}
                  className="w-10 h-10 rounded-full bg-zinc-100 flex items-center justify-center text-[#c7c7cc] active:scale-95 transition-transform"
                >
                  <X size={20} />
                </button>
              </div>

              <div className="flex-1 overflow-y-auto px-6 py-4 space-y-4 scrollbar-hide">
                {logs.length > 0 ? logs.map((log) => (
                  <div key={log.id} className="p-5 rounded-3xl bg-zinc-50 border border-zinc-100/50 flex flex-col gap-3">
                    <div className="flex justify-between items-center text-[10px] font-black uppercase tracking-wider text-[#c7c7cc]">
                      <div className="flex items-center gap-1.5">
                        <Calendar size={12} />
                        {new Date(log.date).toLocaleDateString('ta-IN', { month: 'short', day: 'numeric' })}
                      </div>
                      <div className="flex items-center gap-2">
                        <span>வலி: {log.painLevel}/5</span>
                      </div>
                    </div>
                    
                    <div className="flex items-center justify-between">
                      <div className="flex flex-wrap gap-2 text-xs">
                        {log.symptoms.map(s => (
                          <span key={s} className="px-3 py-1 bg-white border border-zinc-200 rounded-full font-medium text-[#1c1c1e]">
                            {s}
                          </span>
                        ))}
                      </div>
                      <span className="text-lg">{log.mood.split(' ')[0]}</span>
                    </div>
                  </div>
                )) : (
                  <div className="flex flex-col items-center justify-center py-20 text-center">
                    <div className="w-16 h-16 bg-zinc-50 rounded-full flex items-center justify-center mb-4">
                      <Activity className="text-zinc-300" size={32} />
                    </div>
                    <p className="text-[#c7c7cc] font-medium">பதிவுகள் ஏதுமில்லை</p>
                  </div>
                )}
              </div>

              <div className="p-6 pt-2">
                <button 
                  onClick={() => {
                    setShowLogs(false);
                    onNavigate('tracker');
                  }}
                  className="btn-forest w-full"
                >
                  புதிய பதிவு சேர்
                </button>
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </motion.div>
  );
}

