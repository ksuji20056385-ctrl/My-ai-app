import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Check, Calendar as CalendarIcon, ChevronRight } from 'lucide-react';
import { SymptomLog } from '../types';

interface TrackerProps {
  onSave: (log: SymptomLog) => void;
}

export default function Tracker({ onSave }: TrackerProps) {
  const [selectedDate, setSelectedDate] = useState(new Date().toISOString().split('T')[0]);
  const [selectedSymptoms, setSelectedSymptoms] = useState<string[]>([]);
  const [selectedMood, setSelectedMood] = useState<string | null>(null);
  const [painLevel, setPainLevel] = useState(3);
  const [showSuccess, setShowSuccess] = useState(false);
  
  const symptoms = [
    'குறைவான ஓட்டம்', 'மிதமான ஓட்டம்', 'அதிக ஓட்டம்', 'வயிற்று வலி', 'உப்பசம்', 'முகப்பரு', 
    'கருமுட்டை வலி', 'சோர்வு', 'தலைவலி', 'மார்பக மென்மை'
  ];

  const moods = ['😊 மகிழ்ச்சி', '😌 அமைதி', '😔 கவலை', '😤 எரிச்சல்', '😴 சோர்வு'];

  const toggleSymptom = (s: string) => {
    setSelectedSymptoms(prev => 
      prev.includes(s) ? prev.filter(x => x !== s) : [...prev, s]
    );
  };

  const handleSave = () => {
    onSave({
      id: Date.now().toString(),
      date: selectedDate,
      mood: selectedMood || '😊 மகிழ்ச்சி',
      symptoms: selectedSymptoms,
      painLevel,
      notes: ''
    });
    setShowSuccess(true);
    setTimeout(() => setShowSuccess(false), 3000);
  };

  const container = {
    hidden: { opacity: 0 },
    show: {
      opacity: 1,
      transition: { staggerChildren: 0.04, delayChildren: 0.05 }
    }
  };

  const item = {
    hidden: { opacity: 0, scale: 0.98, y: 10 },
    show: { 
      opacity: 1, 
      scale: 1, 
      y: 0, 
      transition: { type: "spring", stiffness: 350, damping: 28 } 
    }
  };

  return (
    <motion.div 
      variants={container}
      initial="hidden"
      animate="show"
      className="space-y-10 pb-16 transform-gpu"
    >
      <header className="text-center space-y-4 pt-4">
        <motion.h1 
          variants={item}
          className="text-4xl font-bold tracking-tight text-[#1c1c1e]"
        >
          பதிவு செய்க
        </motion.h1>
        
        {/* Date Selector */}
        <motion.div variants={item} className="flex justify-center">
          <div className="relative inline-flex items-center gap-3 bg-white/50 backdrop-blur-sm border border-white/60 px-5 py-2.5 rounded-2xl shadow-sm card-interactive">
            <CalendarIcon size={16} className="text-[#14532d]" />
            <input 
              type="date" 
              value={selectedDate}
              onChange={(e) => setSelectedDate(e.target.value)}
              className="bg-transparent text-sm font-bold text-[#14532d] outline-none border-none focus:ring-0 cursor-pointer"
            />
          </div>
        </motion.div>
      </header>

      {/* Mood Selector */}
      <section className="space-y-4">
        <motion.h2 
          variants={item}
          className="text-[10px] font-black uppercase tracking-[0.2em] text-[#c7c7cc] px-1"
        >
          மனநிலை
        </motion.h2>
        <div className="flex overflow-x-auto gap-3 pb-2 scrollbar-hide px-1 touch-pan-x">
          {moods.map((m) => (
            <motion.button 
              key={m}
              variants={item}
              onClick={() => setSelectedMood(m)}
              className={`whitespace-nowrap px-6 py-4 rounded-3xl text-lg transition-all duration-300 transform-gpu ${
                selectedMood === m 
                  ? 'bg-[#14532d] text-white shadow-xl shadow-green-900/10 scale-105' 
                  : 'bg-white border border-zinc-100/50 shadow-sm'
              }`}
            >
              {m}
            </motion.button>
          ))}
        </div>
      </section>

      {/* Symptom Tag Grid */}
      <section className="space-y-4">
        <motion.h2 
          variants={item}
          className="text-[10px] font-black uppercase tracking-[0.2em] text-[#c7c7cc] px-1"
        >
          அறிகுறிகள்
        </motion.h2>
        <motion.div variants={item} className="flex flex-wrap gap-2.5 px-1">
          {symptoms.map((s) => (
            <button
              key={s}
              onClick={() => toggleSymptom(s)}
              className={`px-5 py-3.5 rounded-2xl text-sm font-bold transition-all duration-200 flex items-center gap-2 transform-gpu ${
                selectedSymptoms.includes(s)
                  ? 'bg-[#14532d] text-white shadow-lg shadow-green-900/10 scale-[1.02]'
                  : 'bg-white text-[#1c1c1e] border border-zinc-100/50'
              }`}
            >
              <AnimatePresence>
                {selectedSymptoms.includes(s) && (
                  <motion.div 
                    initial={{ scale: 0, opacity: 0 }} 
                    animate={{ scale: 1, opacity: 1 }}
                    exit={{ scale: 0, opacity: 0 }}
                  >
                    <Check size={14} strokeWidth={3} />
                  </motion.div>
                )}
              </AnimatePresence>
              {s}
            </button>
          ))}
        </motion.div>
      </section>

      {/* Pain Level */}
      <section className="space-y-4">
        <motion.h2 
          variants={item}
          className="text-[10px] font-black uppercase tracking-[0.2em] text-[#c7c7cc] px-1"
        >
          வலி தீவிரம்
        </motion.h2>
        <motion.div variants={item} className="bg-white/50 backdrop-blur-sm p-2 rounded-[2.5rem] border border-white/60 shadow-sm flex items-center transform-gpu">
          {[1, 2, 3, 4, 5].map((level) => (
            <button 
              key={level}
              onClick={() => setPainLevel(level)}
              className={`flex-1 py-4.5 rounded-[2rem] text-xl font-bold transition-all duration-300 overflow-hidden relative ${
                painLevel === level ? 'text-white' : 'text-[#c7c7cc] hover:text-[#1c1c1e]'
              }`}
            >
              <AnimatePresence>
                {painLevel === level && (
                  <motion.div 
                    layoutId="activePain"
                    className="absolute inset-0 bg-[#14532d] z-0"
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    exit={{ opacity: 0 }}
                    transition={{ type: "spring", stiffness: 350, damping: 30 }}
                  />
                )}
              </AnimatePresence>
              <span className="relative z-10">{level}</span>
            </button>
          ))}
        </motion.div>
      </section>

      <motion.div 
        variants={item}
        className="pt-6"
      >
        <button 
          onClick={handleSave}
          className="btn-forest w-full flex items-center justify-center gap-3 transform-gpu"
        >
          பதிவைச் சேமி
          <motion.div
            animate={{ x: [0, 4, 0] }}
            transition={{ repeat: Infinity, duration: 2, ease: "easeInOut" }}
          >
            <ChevronRight size={20} />
          </motion.div>
        </button>
      </motion.div>

      {/* Success Popup */}
      <AnimatePresence>
        {showSuccess && (
          <motion.div 
            initial={{ opacity: 0, y: 50, scale: 0.9 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 20, scale: 0.9 }}
            className="fixed bottom-32 left-8 right-8 z-[100]"
          >
            <div className="bg-[#14532d] text-white px-6 py-5 rounded-[2rem] shadow-2xl flex items-center gap-4 border border-white/10">
              <div className="w-12 h-12 bg-white/20 rounded-full flex items-center justify-center flex-shrink-0">
                <Check size={28} strokeWidth={3} className="text-white" />
              </div>
              <div>
                <h3 className="font-bold text-lg">பதிவு வெற்றிகரம்!</h3>
                <p className="text-white/70 text-sm">உங்கள் தகவல்கள் சேமிக்கப்பட்டன.</p>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  );
}

