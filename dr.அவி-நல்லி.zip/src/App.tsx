import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import Navigation from './components/Navigation';
import Dashboard from './pages/Dashboard';
import Tracker from './pages/Tracker';
import Trends from './pages/Trends';
import { View, PCOSInfo, SymptomLog } from './types';

/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export default function App() {
  const [loading, setLoading] = useState(true);
  const [currentView, setCurrentView] = useState<View>('dashboard');
  const [logs, setLogs] = useState<SymptomLog[]>([
    { id: '1', date: '2026-04-16', symptoms: ['மிதமான ஓட்டம்', 'வயிற்று வலி'], mood: '😔 கவலை', painLevel: 3, notes: '' },
    { id: '2', date: '2026-04-15', symptoms: ['சோர்வு'], mood: '😴 சோர்வு', painLevel: 2, notes: '' },
    { id: '3', date: '2026-04-14', symptoms: ['முகப்பரு'], mood: '😌 அமைதி', painLevel: 1, notes: '' },
    { id: '4', date: '2026-04-13', symptoms: ['தலைவலி'], mood: '😤 எரிச்சல்', painLevel: 4, notes: '' },
  ]);
  const [pcosInfo] = useState<PCOSInfo>({
    nextPeriod: '2026-04-29',
    cycleDay: 14
  });

  useEffect(() => {
    const timer = setTimeout(() => {
      setLoading(false);
    }, 2500);
    return () => clearTimeout(timer);
  }, []);

  if (loading) {
    return (
      <div className="fixed inset-0 bg-[#0a0a0a] flex flex-col items-center justify-center z-[100] overflow-hidden">
        <motion.div 
          initial={{ opacity: 0, scale: 0.8 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ type: "spring", stiffness: 200, damping: 25 }}
          className="flex flex-col items-center"
        >
          <motion.div
            initial={{ y: 30, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ type: "spring", stiffness: 300, damping: 30, delay: 0.2 }}
            className="mb-10 relative"
          >
            <div className="w-40 h-40 rounded-full bg-white flex items-center justify-center shadow-[0_30px_60px_rgba(20,83,45,0.4)] relative group border-4 border-[#14532d]">
              <motion.div
                animate={{ 
                  y: [2, -8, 2],
                  rotate: [0, 3, -3, 0]
                }}
                transition={{ 
                  repeat: Infinity, 
                  duration: 3, 
                  ease: "easeInOut" 
                }}
                className="text-7xl drop-shadow-sm select-none"
              >
                👶
              </motion.div>
              
              <motion.div
                initial={{ scale: 0, rotate: -45 }}
                animate={{ scale: 1, rotate: [0, 10, -10, 0] }}
                transition={{ 
                  scale: { type: "spring", delay: 0.6 },
                  rotate: { repeat: Infinity, duration: 5, ease: "easeInOut" } 
                }}
                className="absolute -bottom-2 -right-2 bg-white w-14 h-14 rounded-2xl shadow-xl flex items-center justify-center border border-[#14532d]/20"
              >
                <div className="text-3xl">🩺</div>
              </motion.div>

              {[0, 90, 180, 270].map((angle, i) => (
                <motion.div
                  key={i}
                  animate={{ 
                    scale: [0, 1.2, 0],
                    opacity: [0, 1, 0],
                    y: [0, -25]
                  }}
                  transition={{ 
                    repeat: Infinity, 
                    duration: 2, 
                    delay: i * 0.5 
                  }}
                  className="absolute text-yellow-400 text-sm"
                  style={{ 
                    top: '50%', 
                    left: '50%',
                    marginLeft: `${Math.cos(angle * Math.PI / 180) * 50}px`,
                    marginTop: `${Math.sin(angle * Math.PI / 180) * 50}px`
                  }}
                >
                  ✨
                </motion.div>
              ))}
            </div>
            
            <motion.div 
              animate={{ 
                scale: [1, 1.2, 1],
                opacity: [0.1, 0.3, 0.1] 
              }}
              transition={{ repeat: Infinity, duration: 4 }}
              className="absolute -inset-6 rounded-full border border-emerald-500/20 pointer-events-none"
            />
          </motion.div>

          <motion.div className="flex flex-col items-center gap-1">
            <motion.h1 
              initial={{ y: 20, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              transition={{ type: "spring", stiffness: 200, damping: 25, delay: 0.4 }}
              className="text-4xl font-bold text-white tracking-tight text-center flex items-center gap-2"
            >
              Dr. <span className="font-medium text-white/90">அவி நல்லி</span>
            </motion.h1>
            <motion.div 
              initial={{ scaleX: 0 }}
              animate={{ scaleX: 1 }}
              transition={{ delay: 0.8, duration: 1, ease: "circOut" }}
              className="h-[2px] w-24 bg-[#14532d] rounded-full"
            />
          </motion.div>
        </motion.div>
      </div>
    );
  }

  const handleSaveLog = (newLog: SymptomLog) => {
    setLogs(prev => [newLog, ...prev].slice(0, 10)); // Keep only last 10
  };

  const renderView = () => {
    switch (currentView) {
      case 'dashboard':
        return <Dashboard info={pcosInfo} onNavigate={setCurrentView} logs={logs} />;
      case 'tracker':
        return <Tracker onSave={handleSaveLog} />;
      case 'trends':
        return <Trends />;
      default:
        return <Dashboard info={pcosInfo} onNavigate={setCurrentView} logs={logs} />;
    }
  };

  return (
    <div className="min-h-screen max-w-lg mx-auto bg-[#f1f4f0] relative overflow-x-hidden">
      <main className="px-4 sm:px-6 pt-12 pb-32">
        <AnimatePresence mode="wait">
          <motion.div
            key={currentView}
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -20 }}
            transition={{ type: "spring", stiffness: 300, damping: 28 }}
          >
            {renderView()}
          </motion.div>
        </AnimatePresence>
      </main>
      
      <div className="fixed bottom-6 sm:bottom-8 left-0 right-0 px-4 sm:px-6 z-50">
        <div className="max-w-lg mx-auto">
          <Navigation 
            currentView={currentView} 
            onNavigate={setCurrentView} 
          />
        </div>
      </div>
    </div>
  );
}
